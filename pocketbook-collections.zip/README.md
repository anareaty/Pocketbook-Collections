# Pocketbook-Collections
This is the plugin for Calibre. It allows to sync Pocketbook collections, read statuses and favorite statuses with Calibre library.
